<?php
date_default_timezone_set('Asia/Jakarta');
$a = date("YmdHis");
echo "$a";
?>