
<!-- search form -->
                    <!--<form action="#" method="get" class="sidebar-form">
                        <div class="input-group">
                            <input type="text" name="q" class="form-control" placeholder="Cari Sesuatu.?"/>
                            <span class="input-group-btn">
                                <button type='submit' name='search' id='search-btn' class="btn btn-flat"><i class="fa fa-search"></i></button>
                            </span>
                        </div>
                    </form>-->
                    <!-- /.search form -->
                    <!-- sidebar menu: : style can be found in sidebar.less --><br />
                    <ul class="sidebar-menu">
                        <li class="active">
                            <a href="index.php">
                                <i class="glyphicon glyphicon-dashboard"></i> <span>Dashboard</span>
                            </a>
                        </li>
                          
                               
                            </a>
                            <ul class="treeview-menu">
                               
                            </ul>
                        </li>
                        <li class="treeview">
                            <a href="#">
                                <i class="glyphicon glyphicon-link"></i>
                                <span>Produk</span>
                                <i class="fa fa-angle-left pull-right"></i>
                            </a>
                            <ul class="treeview-menu">
                                <li><a href="produk.php"><i class="fa fa-angle-double-right"></i> Produk</a></li>
                                <li><a href="input-produk.php"><i class="fa fa-angle-double-right"></i> Tambah Produk</a></li>
                            </ul>
                        </li>

                        <li class="treeview">
                            <a href="#">
                                <i class="glyphicon glyphicon-usd"></i> <span>Purchase Order</span>
                                <i class="fa fa-angle-left pull-right"></i>
                            </a>
                            <ul class="treeview-menu">
                                <li><a href="po-terima.php"><i class="fa fa-angle-double-right"></i> Data PO Terima</a></li>
                                <li><a href="konfirmasi.php"><i class="fa fa-angle-double-right"></i> Konfirmasi Pembayaran</a></li>
                                <li><a href="po.php"><i class="fa fa-angle-double-right"></i> Data PO Kirim</a></li>
                            </ul>
                        </li>

                        <li class="treeview">
                            <a href="#">
                                <i class="glyphicon glyphicon-lock"></i> <span>Admin</span>
                                <i class="fa fa-angle-left pull-right"></i>
                            </a>
                            <ul class="treeview-menu">
                                <li><a href="admin.php"><i class="fa fa-angle-double-right"></i>Data Admin</a></li>
                                <li><a href="input-admin.php"><i class="fa fa-angle-double-right"></i>Tambah Admin</a></li>
                            </ul>
                        </li>

                        <li class="treeview">
                            <a href="#">
                                <i class="glyphicon glyphicon-file"></i> <span>Laporan</span>
                                <i class="fa fa-angle-left pull-right"></i>
                            </a>
                            <ul class="treeview-menu">
                                <li><a href="cetak-produk.php"><i class="fa fa-angle-double-right"></i> Laporan Product</a></li>
                                <li><a href="cetak-customer.php"><i class="fa fa-angle-double-right"></i> Laporan Data Customer</a></li>
                            </ul>
                        </li>
                        </ul>
                        <!--<li class="treeview">
                            <a href="#">
                                <i class="glyphicon glyphicon-usd"></i> <span>Purchase Order</span>
                                <i class="fa fa-angle-left pull-right"></i>
                            </a>
                            <ul class="treeview-menu">
                                <li><a href="po.php"><i class="fa fa-angle-double-right"></i> Data PO</a></li>
                                <li><a href="input-po.php"><i class="fa fa-angle-double-right"></i> Input PO</a></li>
                            </ul>
                        </li>-->
                        
                        